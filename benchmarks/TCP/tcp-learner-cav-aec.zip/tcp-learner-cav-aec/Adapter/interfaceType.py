# class for interfaces Only ethernet works thus far
class InterfaceType:
    Wireless, Ethernet = range(0,2)