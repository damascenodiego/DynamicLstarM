package learner;


public class Config {
	public LearningParams learningParams;
	public TCPParams tcpParams;
}
