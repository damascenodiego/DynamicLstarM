package util;

import java.io.IOException;
import java.io.OutputStream;

public class NullStream extends OutputStream {
	@Override
	public void write(int b) throws IOException {
		
	}
}
