package util.exceptions;

public class CheckException extends RuntimeException {
	private static final long serialVersionUID = 7179979233467180421L;

	public CheckException(String message) {
		super(message);
	}	
	
}
