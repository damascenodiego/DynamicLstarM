package util.exceptions;

public class BugException extends CheckException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BugException(String message) {
		super(message);
	}

}
