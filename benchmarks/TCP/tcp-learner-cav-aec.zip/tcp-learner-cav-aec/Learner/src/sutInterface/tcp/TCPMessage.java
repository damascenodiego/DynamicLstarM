package sutInterface.tcp;

public interface TCPMessage {
	public String serialize();
}
